﻿using System;

namespace LegacyApp
{
    /*
     * DO NOT CHANGE THIS FILE AT ALL
     */
    public static class UserDataAccess
    {
        public static void AddUser(User user)
        {
            //...
            Console.WriteLine($"Added the user {user} successfully");
        }
    }
}
